
    <script src="<?php echo base_url('assets');?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/jquery.appear/jquery.appear.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/jquery.cookie/jquery.cookie.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/jquery.validation/jquery.validate.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/jquery.gmap/jquery.gmap.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/lazysizes/lazysizes.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/isotope/jquery.isotope.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/owl.carousel/owl.carousel.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/vide/jquery.vide.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/vivus/vivus.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="<?php echo base_url('assets');?>/js/theme.js"></script>

        <!-- Circle Flip Slideshow Script -->
        <script src="<?php echo base_url('assets');?>/vendor/circle-flip-slideshow/js/jquery.flipshow.min.js"></script>
    <!-- Current Page Views -->
    <script src="<?php echo base_url('assets');?>/js/views/view.home.js"></script>

    <!-- Theme Custom -->
    <script src="<?php echo base_url('assets');?>/js/custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="<?php echo base_url('assets');?>/js/theme.init.js"></script>

    <!-- Examples -->
    <script src="<?php echo base_url('assets');?>/js/examples/examples.portfolio.js"></script>
</body>